//
//  MADCustomEventWithGADBanner.h
//  Part of MADNET iOS SDK -> http://madnet.ru
//
//  Created by Andrey Ivanov.
//  Copyright 2013 TinkoffDigital. All rights reserved.
//  Copyright 2013 MADNET. All rights reserved.
//

@interface MADCustomEventWithGADBanner : NSObject
@end

